java -jar BSimGUI.jar

javac -cp .:./lib/BSim3.0.jar MyBSimSimulation.java

java -cp .:./lib/BSim3.0.jar MyBSimSimulation

rm *.class